import React from "react";

function ContactPages() {
    return (
        <div>
            <h2>Contato</h2>
            <p>Aqui você pode encontrar maneiras de entrar em contato conosco.</p>
            <p>Telefone: +55 11 95375-1407</p>
            <p>Aceitamos reclamações qualquer hora do dia só mandar, use e abuse😃</p>
        </div>
    );
}

export default ContactPages;